/** @format */

const water_right_document = (sequelize, DataTypes) => {
  const Water_right_document = sequelize.define("water_right_document", {
		id: {type: DataTypes.INTEGER, primaryKey: true},
		user_id: DataTypes.STRING,
		location_id: DataTypes.INTEGER,
		name: DataTypes.STRING,
		water_right_number:  DataTypes.STRING,
		document_type: DataTypes.STRING,
		filename: DataTypes.STRING,
		last_edit: DataTypes.STRING,
		deleted: DataTypes.INTEGER,
		validated: DataTypes.INTEGER
  });
  return Water_right_document;
};

module.exports = water_right_document;