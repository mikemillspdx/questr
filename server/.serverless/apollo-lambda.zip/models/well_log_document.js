/** @format */

const well_log_document = (sequelize, DataTypes) => {
  const Well_log_document = sequelize.define("well_log_document", {
		id: {type: DataTypes.INTEGER, primaryKey: true},
		user_id: DataTypes.STRING,
		location_id: DataTypes.INTEGER,
		name: DataTypes.STRING,
		well_log_name:  DataTypes.STRING,
		document_type: DataTypes.STRING,
		filename: DataTypes.STRING,
		last_edit: DataTypes.STRING,
		deleted: DataTypes.INTEGER,
		validated: DataTypes.INTEGER
  });
  return Well_log_document;
};

module.exports = well_log_document;