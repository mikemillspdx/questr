/** @format */

const pump = (sequelize, DataTypes) => {
  const Pump = sequelize.define("pump", {
		id: {type: DataTypes.INTEGER, primaryKey: true},
		user_id: DataTypes.STRING,
		location_id: DataTypes.INTEGER,
		last_edit: DataTypes.STRING,
		deleted: DataTypes.INTEGER,
		validated: DataTypes.INTEGER,		
		pump_model: DataTypes.STRING,
		pump_sku: DataTypes.STRING,
		serial_number: DataTypes.STRING,
		pump_min_gpm: DataTypes.INTEGER,
		pump_max_gpm: DataTypes.INTEGER,
		pump_type: DataTypes.STRING,
		pump_purchase_date: DataTypes.STRING,
		pump_install_date: DataTypes.STRING,
		pump_maintenance_date: DataTypes.STRING,
		pump_curve_url: DataTypes.STRING
  });
  return Pump;
};

module.exports =  pump;