/** @format */

const fish_screen = (sequelize, DataTypes) => {
  const Fish_screen = sequelize.define("fish_screen", {
		id: {type: DataTypes.INTEGER, primaryKey: true},
		user_id: DataTypes.STRING,
		location_id: DataTypes.INTEGER,
		name: DataTypes.STRING,
		mesh_size: DataTypes.STRING,
		screen_type: DataTypes.STRING,
		rotating_drum: DataTypes.STRING,
		last_inspection: DataTypes.STRING,
		screen_photo: DataTypes.STRING,
		last_edit: DataTypes.STRING,
		deleted: DataTypes.INTEGER,
		validated: DataTypes.INTEGER
  });
  return Fish_screen;
};

module.exports =  fish_screen;