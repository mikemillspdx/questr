/** @format */

const Sequelize = require('sequelize');

let sequelize;
let PORT=3000;
let DATABASE='riverbank';
let DATABASE_USER='postgres';
let DATABASE_PASSWORD='P%ssword39';
let DATABASE_URL='riverbank-serverless.cjv6txmpepuf.us-west-2.rds.amazonaws.com';
let DATABASE_PORT='5432';

sequelize = new Sequelize(
			DATABASE,
			DATABASE_USER,
			DATABASE_PASSWORD, 
		{
		  host: DATABASE_URL,
		  port: DATABASE_PORT,
		  dialect: 'postgres'
		});
		


const models = {
  water_rights: sequelize.import("./water_right"),
  water_right_documents: sequelize.import("./water_right_document"),
  locations: sequelize.import("./location"),
  location_tasks: sequelize.import("./location_task"),  
  fish_screens: sequelize.import("./fish_screen"),
  motors: sequelize.import("./motor"),  
  meters: sequelize.import("./meter"),  
  pumps: sequelize.import("./pump"), 
  well_logs: sequelize.import("./well_log"),
  well_log_documents: sequelize.import("./well_log_document")
  //meter_documents: sequelize.import("./meter_document"),
  //motor_documents: sequelize.import("./motors_document"),
  //pump_documents: sequelize.import("./pump_document"),
  //fish_screen_documents: sequelize.import("./fish_screen_document")
};

Object.keys(models).forEach((key) => {
  if ("associate" in models[key]) {
    models[key].associate(models);
  }
});


module.exports = { sequelize };

module.exports = models;
