/** @format */

const meter = (sequelize, DataTypes) => {
  const Meter = sequelize.define("meter", {
		id: {type: DataTypes.INTEGER, primaryKey: true},
		user_id: DataTypes.STRING,
		location_id: DataTypes.INTEGER,
		name: DataTypes.STRING,
		last_edit: DataTypes.STRING,
		deleted: DataTypes.INTEGER,
		validated: DataTypes.INTEGER,
		meter_flow_type: DataTypes.STRING,
		meter_measure_source_num: DataTypes.INTEGER,
		meter_distance_from_source: DataTypes.BOOLEAN,
		meter_type: DataTypes.STRING,
		meter_brand: DataTypes.STRING,
		meter_model_number: DataTypes.STRING,
		meter_serial_number: DataTypes.STRING,
		meter_measure: DataTypes.STRING,
		meter_device_rollover: DataTypes.INTEGER,
		meter_fish_screen: DataTypes.BOOLEAN,
		meter_device_multiplier: DataTypes.INTEGER,
		meter_install_date: DataTypes.STRING,
		meter_calibration_date: DataTypes.STRING,
		meter_maintenance_date: DataTypes.STRING
  });
  return Meter;
};

module.exports =  meter;