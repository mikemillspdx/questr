/** @format */

const pump_document = (sequelize, DataTypes) => {
  const Pump_document = sequelize.define("pump_document", {
		id: {type: DataTypes.INTEGER, primaryKey: true},
		user_id: DataTypes.STRING,
		location_id: DataTypes.INTEGER,
		name: DataTypes.STRING,
		pump_name:  DataTypes.STRING,
		document_type: DataTypes.STRING,
		filename: DataTypes.STRING,
		last_edit: DataTypes.STRING,
		deleted: DataTypes.INTEGER,
		validated: DataTypes.INTEGER
  });
  return Pump_document;
};

module.exports = pump_document;