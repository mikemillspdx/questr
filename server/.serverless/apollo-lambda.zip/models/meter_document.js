/** @format */

const meter_document = (sequelize, DataTypes) => {
  const Meter_document = sequelize.define("meter_document", {
		id: {type: DataTypes.INTEGER, primaryKey: true},
		user_id: DataTypes.STRING,
		location_id: DataTypes.INTEGER,
		name: DataTypes.STRING,
		meter_name:  DataTypes.STRING,
		document_type: DataTypes.STRING,
		filename: DataTypes.STRING,
		last_edit: DataTypes.STRING,
		deleted: DataTypes.INTEGER,
		validated: DataTypes.INTEGER
  });
  return Meter_document;
};

module.exports = meter_document;