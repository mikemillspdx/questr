/** @format */

const motor = (sequelize, DataTypes) => {
  const Motor = sequelize.define("motor", {
		id: {type: DataTypes.INTEGER, primaryKey: true},
		user_id: DataTypes.STRING,
		location_id: DataTypes.INTEGER,
		last_edit: DataTypes.STRING,
		deleted: DataTypes.INTEGER,
		validated: DataTypes.INTEGER,		
		motor_model: DataTypes.STRING,
		motor_sku: DataTypes.STRING,
		serial_number: DataTypes.STRING,
		motor_purchase_date: DataTypes.STRING,
		motor_install_date: DataTypes.STRING,
		motor_maintenance_date: DataTypes.STRING,
		motor_pump_size: DataTypes.STRING,
		motor_impeller_size: DataTypes.INTEGER,
		motor_type: DataTypes.STRING
  });
  return Motor;
};

module.exports =  motor;