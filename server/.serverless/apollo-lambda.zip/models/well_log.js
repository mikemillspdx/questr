/** @format */

const well_log = (sequelize, DataTypes) => {
  const Well_log = sequelize.define("well_log", {
		id: {type: DataTypes.INTEGER, primaryKey: true},
		user_id: DataTypes.STRING,
		location_id: DataTypes.INTEGER,
		name: DataTypes.STRING,
		ecy_id: DataTypes.STRING,
		diameter: DataTypes.STRING,
		depth: DataTypes.STRING,
		aquifer: DataTypes.STRING,
		pump: DataTypes.STRING,
		water_right: DataTypes.STRING,
		last_edit: DataTypes.STRING,
		deleted: DataTypes.INTEGER,
		validated: DataTypes.INTEGER
  });
  return Well_log;
};

module.exports =  well_log;