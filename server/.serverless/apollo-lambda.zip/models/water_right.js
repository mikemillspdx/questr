/** @format */

const water_right = (sequelize, DataTypes) => {
  const Water_right = sequelize.define("water_right", {
		id: {type: DataTypes.INTEGER, primaryKey: true},
		user_id: DataTypes.STRING,
		location_id: DataTypes.INTEGER,
		name: DataTypes.STRING,
		water_source:  DataTypes.STRING,
		water_right_number: DataTypes.STRING,
		rate: DataTypes.FLOAT,
		rate_unit: DataTypes.STRING,
		volume: DataTypes.FLOAT,
		volume_unit: DataTypes.STRING,
		acres: DataTypes.FLOAT,
		water_right_type: DataTypes.STRING,
		notes: DataTypes.STRING,
		last_edit: DataTypes.STRING,
		deleted: DataTypes.INTEGER,
		validated: DataTypes.INTEGER
  });
  return Water_right;
};

module.exports = water_right;