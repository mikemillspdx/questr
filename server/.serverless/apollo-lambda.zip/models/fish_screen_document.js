/** @format */

const fish_screen_document = (sequelize, DataTypes) => {
  const Fish_screen_document = sequelize.define("fish_screen_document", {
		id: {type: DataTypes.INTEGER, primaryKey: true},
		user_id: DataTypes.STRING,
		location_id: DataTypes.INTEGER,
		name: DataTypes.STRING,
		fish_screen_name:  DataTypes.STRING,
		document_type: DataTypes.STRING,
		filename: DataTypes.STRING,
		last_edit: DataTypes.STRING,
		deleted: DataTypes.INTEGER,
		validated: DataTypes.INTEGER
  });
  return Fish_screen_document;
};

module.exports = fish_screen_document;