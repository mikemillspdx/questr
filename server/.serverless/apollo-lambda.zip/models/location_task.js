/** @format */

const location_task = (sequelize, DataTypes) => {
  const LocationTask = sequelize.define("location_task", {
		id: {type: DataTypes.INTEGER, primaryKey: true},
		user_id: DataTypes.STRING,
		location_id: DataTypes.INTEGER,
		task: DataTypes.STRING,
  });
  return LocationTask
};

module.exports = location_task;
