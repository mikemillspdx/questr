/** @format */


const uuidv4 = require('uuidv4');

module.exports = {
  Query: {
    location_tasks: async (parent, args, { models }) => {
      console.log(models)
      return await models.location_tasks.findAll();
    },
	
	location_tasks_by_location: async (parent, { location_id }, { models }) => {
      console.log(models)
      return await models.location_tasks.findAll({
          where: {
            location_id: location_id
          }
        });
    },
	
    location_task: async (parent, { id }, { models }) => {
      return await models.location_tasks.findByPk(id);
    }
  },

  Mutation: {
    createNewLocationTask: async (parent, { task }, { models }) => {
      return await models.location_tasks.create({
        task
      });
    },

    deleteLocationTask: async (parent, { id }, { models }) => {
      return await models.location_tasks.destroy({
        where: {
          id
        }
      });
    },
    updateLocationTask: async (parent, { id, task }, { models }) => {
      await models.location_tasks.update(
        {
          task
        },
        {
          where: {
            id: id
          }
        }
      );
      const updatedLocationTask = await models.location_tasks.findByPk(id, {
      });
      return updatedLocationTask;
    }
  }
};
