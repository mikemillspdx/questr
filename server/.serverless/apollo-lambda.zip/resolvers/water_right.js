/** @format */

const uuidv4 = require('uuidv4');

module.exports = {
  Query: {
    water_rights: async (parent, args, { models }) => {
      console.log(models)
      return await models.water_rights.findAll();
    },
	
	
    water_rights_by_location: async (parent, { location_id }, { models }) => {
      console.log(models)
      return await models.water_rights.findAll({
          where: {
            location_id: location_id
          }
        });
    },

    water_right: async (parent, { id }, { models }) => {
      return await models.water_rights.findByPk(id);
    }
  },

  Mutation: {
	
    getWaterRightByLocation: async (parent,  { location_id }, { models }) => {
      console.log(models)
      return await models.water_rights.findAll({
          where: {
            location_id: location_id
          }
        });
    },
	  
    createNewWaterRight: async (parent, { name }, { models }) => {
      return await models.water_rights.create({
        name
      });
    },

    deleteWaterRight: async (parent, { id }, { models }) => {
      return await models.water_rights.destroy({
        where: {
          id
        }
      });
    },
    updateWaterRight: async (parent, { id, name }, { models }) => {
      await models.water_rights.update(
        {
          name
        },
        {
          where: {
            id: id
          }
        }
      );
      const updatedWaterRight = await models.water_rights.findByPk(id, {
      });
      return updatedWaterRight;
    }
  }
};
