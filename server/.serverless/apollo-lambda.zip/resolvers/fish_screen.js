/** @format */

const uuidv4 = require('uuidv4');

module.exports = {
  Query: {
    fish_screens: async (parent, args, { models }) => {
      console.log(models)
      return await models.fish_screens.findAll();
    },
	
	
    fish_screens_by_location: async (parent, { location_id }, { models }) => {
      console.log(models)
      return await models.fish_screens.findAll({
          where: {
            location_id: location_id
          }
        });
    },

    fish_screen: async (parent, { id }, { models }) => {
      return await models.fish_screens.findByPk(id);
    }
  },

  Mutation: {
	
    getFishScreensByLocation: async (parent,  { location_id }, { models }) => {
      console.log(models)
      return await models.fish_screens.findAll({
          where: {
            location_id: location_id
          }
        });
    },
	  
    createNewFishScreen: async (parent, { name }, { models }) => {
      return await models.fish_screens.create({
        name
      });
    },

    deleteFishScreen: async (parent, { id }, { models }) => {
      return await models.fish_screens.destroy({
        where: {
          id
        }
      });
    },
    updateFishScreen: async (parent, { id, name }, { models }) => {
      await models.fish_screens.update(
        {
          name
        },
        {
          where: {
            id: id
          }
        }
      );
      const updatedFishScreen = await models.fish_screens.findByPk(id, {
      });
      return updatedFishScreen;
    }
  }
};
