/** @format */

const uuidv4 = require('uuidv4');

module.exports = {
  Query: {
    well_logs: async (parent, args, { models }) => {
      console.log(models)
      return await models.well_logs.findAll();
    },
	
	
    well_logs_by_location: async (parent, { location_id }, { models }) => {
      console.log(models)
      return await models.well_logs.findAll({
          where: {
            location_id: location_id
          }
        });
    },

    well_log: async (parent, { id }, { models }) => {
      return await models.well_logs.findByPk(id);
    }
  },

  Mutation: {
	
    getWellLogsByLocation: async (parent,  { location_id }, { models }) => {
      console.log(models)
      return await models.well_logs.findAll({
          where: {
            location_id: location_id
          }
        });
    },
	  
    createNewWellLog: async (parent, { name }, { models }) => {
      return await models.well_logs.create({
        name
      });
    },

    deleteWellLog: async (parent, { id }, { models }) => {
      return await models.well_logs.destroy({
        where: {
          id
        }
      });
    },
    updateWellLog: async (parent, { id, name }, { models }) => {
      await models.well_logs.update(
        {
          name
        },
        {
          where: {
            id: id
          }
        }
      );
      const updatedWellLog = await models.well_logs.findByPk(id, {
      });
      return updatedPump;
    }
  }
};
