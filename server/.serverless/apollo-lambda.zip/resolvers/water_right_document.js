/** @format */

const uuidv4 = require('uuidv4');

module.exports =  {
  Query: {
    water_right_documents: async (parent, args, { models }) => {
      console.log(models)
      return await models.water_right_documents.findAll();
    },

    water_right_documents_by_location: async (parent, { location_id }, { models }) => {
      console.log(models)
      return await models.water_right_documents.findAll({
          where: {
            location_id: location_id
          }
        });
    },
    water_right_document: async (parent, { id }, { models }) => {
      return await models.water_right_documents.findByPk(id);
    }
  },

  Mutation: {
    createNewWaterRightDocument: async (parent, { name }, { models }) => {
      return await models.water_right_documents.create({
        name
      });
    },

    deleteWaterRightDocument: async (parent, { id }, { models }) => {
      return await models.water_right_documents.destroy({
        where: {
          id
        }
      });
    },
    updateWaterRightDocument: async (parent, { id, name }, { models }) => {
      await models.water_right_documents.update(
        {
          name
        },
        {
          where: {
            id: id
          }
        }
      );
      const updatedWaterRightDocument = await models.water_right_documents.findByPk(id, {
      });
      return updatedWaterRightDocument;
    }
  }
};
