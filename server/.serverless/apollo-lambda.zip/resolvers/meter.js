/** @format */

const uuidv4 = require('uuidv4');

module.exports = {
  Query: {
    meters: async (parent, args, { models }) => {
      console.log(models)
      return await models.meters.findAll();
    },
	
	
    meters_by_location: async (parent, { location_id }, { models }) => {
      console.log(models)
      return await models.meters.findAll({
          where: {
            location_id: location_id
          }
        });
    },

    meter: async (parent, { id }, { models }) => {
      return await models.meters.findByPk(id);
    }
  },

  Mutation: {
	
    getMetersByLocation: async (parent,  { location_id }, { models }) => {
      console.log(models)
      return await models.meters.findAll({
          where: {
            location_id: location_id
          }
        });
    },
	  
    createNewMeter: async (parent, { name }, { models }) => {
      return await models.meters.create({
        name
      });
    },

    deleteMeter: async (parent, { id }, { models }) => {
      return await models.meters.destroy({
        where: {
          id
        }
      });
    },
    updateMeter: async (parent, { id, name }, { models }) => {
      await models.meters.update(
        {
          name
        },
        {
          where: {
            id: id
          }
        }
      );
      const updatedMeter = await models.meters.findByPk(id, {
      });
      return updatedPump;
    }
  }
};
