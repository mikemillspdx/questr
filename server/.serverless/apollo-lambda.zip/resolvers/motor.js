/** @format */

const uuidv4 = require('uuidv4');

module.exports = {
  Query: {
    motors: async (parent, args, { models }) => {
      console.log(models)
      return await models.motors.findAll();
    },
	
	
    motors_by_location: async (parent, { location_id }, { models }) => {
      console.log(models)
      return await models.motors.findAll({
          where: {
            location_id: location_id
          }
        });
    },

    motor: async (parent, { id }, { models }) => {
      return await models.motors.findByPk(id);
    }
  },

  Mutation: {
	
    getMotorsByLocation: async (parent,  { location_id }, { models }) => {
      console.log(models)
      return await models.motors.findAll({
          where: {
            location_id: location_id
          }
        });
    },
	  
    createNewMotor: async (parent, { name }, { models }) => {
      return await models.motors.create({
        name
      });
    },

    deleteMotor: async (parent, { id }, { models }) => {
      return await models.motors.destroy({
        where: {
          id
        }
      });
    },
    updateMotor: async (parent, { id, name }, { models }) => {
      await models.motors.update(
        {
          name
        },
        {
          where: {
            id: id
          }
        }
      );
      const updatedMotor = await models.motors.findByPk(id, {
      });
      return updatedPump;
    }
  }
};
