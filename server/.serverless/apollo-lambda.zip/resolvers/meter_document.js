/** @format */

const uuidv4 = require('uuidv4');

module.exports =  {
  Query: {
    meter_documents: async (parent, args, { models }) => {
      console.log(models)
      return await models.meter_documents.findAll();
    },

    meter_documents_by_location: async (parent, { location_id }, { models }) => {
      console.log(models)
      return await models.meter_documents.findAll({
          where: {
            location_id: location_id
          }
        });
    },
    meter_document: async (parent, { id }, { models }) => {
      return await models.meter_documents.findByPk(id);
    }
  },

  Mutation: {
    createNewMeterDocument: async (parent, { name }, { models }) => {
      return await models.meter_documents.create({
        name
      });
    },

    deleteMeterDocument: async (parent, { id }, { models }) => {
      return await models.meter_documents.destroy({
        where: {
          id
        }
      });
    },
    updateMeterDocument: async (parent, { id, name }, { models }) => {
      await models.meter_documents.update(
        {
          name
        },
        {
          where: {
            id: id
          }
        }
      );
      const updatedMeterDocument = await models.meter_documents.findByPk(id, {
      });
      return updatedMeterDocument;
    }
  }
};
