/** @format */

const uuidv4 = require('uuidv4');

module.exports =  {
  Query: {
    motor_documents: async (parent, args, { models }) => {
      console.log(models)
      return await models.motor_documents.findAll();
    },

    motor_documents_by_location: async (parent, { location_id }, { models }) => {
      console.log(models)
      return await models.motor_documents.findAll({
          where: {
            location_id: location_id
          }
        });
    },
    motor_document: async (parent, { id }, { models }) => {
      return await models.motor_documents.findByPk(id);
    }
  },

  Mutation: {
    createNewMotorDocument: async (parent, { name }, { models }) => {
      return await models.motor_documents.create({
        name
      });
    },

    deleteMotorDocument: async (parent, { id }, { models }) => {
      return await models.motor_documents.destroy({
        where: {
          id
        }
      });
    },
    updateMotorDocument: async (parent, { id, name }, { models }) => {
      await models.motor_documents.update(
        {
          name
        },
        {
          where: {
            id: id
          }
        }
      );
      const updatedMotorDocument = await models.motor_documents.findByPk(id, {
      });
      return updatedMotorDocument;
    }
  }
};
