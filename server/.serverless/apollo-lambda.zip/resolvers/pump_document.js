/** @format */

const uuidv4 = require('uuidv4');

module.exports =  {
  Query: {
    pump_documents: async (parent, args, { models }) => {
      console.log(models)
      return await models.pump_documents.findAll();
    },

    pump_documents_by_location: async (parent, { location_id }, { models }) => {
      console.log(models)
      return await models.pump_documents.findAll({
          where: {
            location_id: location_id
          }
        });
    },
    pump_document: async (parent, { id }, { models }) => {
      return await models.pump_documents.findByPk(id);
    }
  },

  Mutation: {
    createNewPumpDocument: async (parent, { name }, { models }) => {
      return await models.pump_documents.create({
        name
      });
    },

    deletePumpDocument: async (parent, { id }, { models }) => {
      return await models.pump_documents.destroy({
        where: {
          id
        }
      });
    },
    updatePumpDocument: async (parent, { id, name }, { models }) => {
      await models.pump_documents.update(
        {
          name
        },
        {
          where: {
            id: id
          }
        }
      );
      const updatedPumpDocument = await models.pump_documents.findByPk(id, {
      });
      return updatedPumpDocument;
    }
  }
};
