/** @format */

const uuidv4 = require('uuidv4');

module.exports =  {
  Query: {
    fish_screen_documents: async (parent, args, { models }) => {
      console.log(models)
      return await models.fish_screen_documents.findAll();
    },

    fish_screen_documents_by_location: async (parent, { location_id }, { models }) => {
      console.log(models)
      return await models.fish_screen_documents.findAll({
          where: {
            location_id: location_id
          }
        });
    },
    fish_screen_document: async (parent, { id }, { models }) => {
      return await models.fish_screen_documents.findByPk(id);
    }
  },

  Mutation: {
    createNewFishScreenDocument: async (parent, { name }, { models }) => {
      return await models.fish_screen_documents.create({
        name
      });
    },

    deleteFishScreenDocument: async (parent, { id }, { models }) => {
      return await models.fish_screen_documents.destroy({
        where: {
          id
        }
      });
    },
    updateFishScreenDocument: async (parent, { id, name }, { models }) => {
      await models.fish_screen_documents.update(
        {
          name
        },
        {
          where: {
            id: id
          }
        }
      );
      const updatedFishScreenDocument = await models.fish_screen_documents.findByPk(id, {
      });
      return updatedFishScreenDocument;
    }
  }
};
