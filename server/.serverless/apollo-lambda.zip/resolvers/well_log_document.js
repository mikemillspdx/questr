/** @format */

const uuidv4 = require('uuidv4');

module.exports =  {
  Query: {
    well_log_documents: async (parent, args, { models }) => {
      console.log(models)
      return await models.well_log_documents.findAll();
    },

    well_log_documents_by_location: async (parent, { location_id }, { models }) => {
      console.log(models)
      return await models.well_log_documents.findAll({
          where: {
            location_id: location_id
          }
        });
    },
    well_log_document: async (parent, { id }, { models }) => {
      return await models.well_log_documents.findByPk(id);
    }
  },

  Mutation: {
    createNewWellLogDocument: async (parent, { name }, { models }) => {
      return await models.well_log_documents.create({
        name
      });
    },

    deleteWellLogDocument: async (parent, { id }, { models }) => {
      return await models.well_log_documents.destroy({
        where: {
          id
        }
      });
    },
    updateWellLogDocument: async (parent, { id, name }, { models }) => {
      await models.well_log_documents.update(
        {
          name
        },
        {
          where: {
            id: id
          }
        }
      );
      const updatedWellLogDocument = await models.well_log_documents.findByPk(id, {
      });
      return updatedWellLogDocument;
    }
  }
};
