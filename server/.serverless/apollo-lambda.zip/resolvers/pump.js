/** @format */

const uuidv4 = require('uuidv4');

module.exports = {
  Query: {
    pumps: async (parent, args, { models }) => {
      console.log(models)
      return await models.pumps.findAll();
    },
	
	
    pumps_by_location: async (parent, { location_id }, { models }) => {
      console.log(models)
      return await models.pumps.findAll({
          where: {
            location_id: location_id
          }
        });
    },

    pump: async (parent, { id }, { models }) => {
      return await models.pumps.findByPk(id);
    }
  },

  Mutation: {
	
    getPumpsByLocation: async (parent,  { location_id }, { models }) => {
      console.log(models)
      return await models.pumps.findAll({
          where: {
            location_id: location_id
          }
        });
    },
	  
    createNewPump: async (parent, { name }, { models }) => {
      return await models.pumps.create({
        name
      });
    },

    deletePump: async (parent, { id }, { models }) => {
      return await models.pumps.destroy({
        where: {
          id
        }
      });
    },
    updatePump: async (parent, { id, name }, { models }) => {
      await models.pumps.update(
        {
          name
        },
        {
          where: {
            id: id
          }
        }
      );
      const updatedPump = await models.pumps.findByPk(id, {
      });
      return updatedPump;
    }
  }
};
