/** @format */

const waterRightResolvers = require("./water_right");
const waterRightDocumentResolvers = require("./water_right_document");
const locationResolvers = require("./location");
const locationTaskResolvers = require("./location_task");
const pumpResolvers = require("./pump");
const motorResolvers = require("./motor");
const meterResolvers = require("./meter");
const wellLogResolvers = require("./well_log");
const wellLogDocumentResolvers = require("./well_log_document");
const fishScreenResolvers = require("./fish_screen");
//const pumpDocumentResolvers = require("./pump_document");
//const meterDocumentResolvers = require("./meter_document");
//const motorDocumentResolvers = require("./motor_document");
//const fishScreenDocumentResolvers = require("./fish_screen_document");

//module.exports = [waterRightResolvers, waterRightDocumentResolvers, locationTaskResolvers, locationResolvers, pumpResolvers, motorResolvers, meterResolvers, wellLogResolvers, fishScreenResolvers, wellLogDocumentResolvers, fishScreenDocumentResolvers, meterDocumentResolvers, motorDocumentResolvers, pumpDocumentResolvers];

module.exports = [waterRightResolvers, waterRightDocumentResolvers, locationTaskResolvers, locationResolvers, pumpResolvers, motorResolvers, meterResolvers, wellLogResolvers, fishScreenResolvers, wellLogDocumentResolvers];
