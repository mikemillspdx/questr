/** @format */

const { gql } = require('apollo-server-lambda');

module.exports = gql`
  extend type Query {
    location_tasks: [LocationTask]
    location_task(id: ID!): LocationTask!
    location_tasks_by_location(location_id: ID!): [LocationTask]
  }

  extend type Mutation {
    createNewLocationTask(text: String!): LocationTask!
    deleteLocationTask(id: ID!): Boolean!
    updateLocationTask(id: ID!, name: String!): LocationTask!
  }

  type LocationTask {
    id: ID!
	user_id: String
    location_id: Int
    task: String
  }
`;
