/** @format */

const { gql } = require('apollo-server-lambda');
const waterRightSchema = require("./water_right");
const waterRightDocumentSchema = require("./water_right_document");
const locationSchema = require("./location");
const locationTaskSchema = require("./location_task");
const fishScreenSchema = require("./fish_screen");
const meterSchema = require("./meter");
const motorSchema = require("./motor");
const wellLogSchema = require("./well_log");
const wellLogDocumentSchema = require("./well_log_document");
//const fishScreenDocumentSchema = require("./fish_screen_document");
//const meterDocumentSchema = require("./meter_document");
//const motorDocumentSchema = require("./motor_document");
//const pumpDocumentSchema = require("./pump_document");
const pumpSchema = require("./pump");

const linkSchema = gql`
  type Query {
    _: Boolean
  }

  type Mutation {
    _: Boolean
  }

  type Subscription {
    _: Boolean
  }
`;

module.exports = [linkSchema, waterRightSchema, locationSchema, locationTaskSchema, waterRightDocumentSchema, fishScreenSchema, meterSchema, motorSchema, wellLogSchema, pumpSchema, wellLogDocumentSchema];
//module.exports = [linkSchema, waterRightSchema, locationSchema, locationTaskSchema, waterRightDocumentSchema, fishScreenSchema, meterSchema, motorSchema, wellLogSchema, pumpSchema, wellLogDocumentSchema, fishScreenDocumentSchema, meterDocumentSchema, motorDocumentSchema, pumpDocumentSchema];
