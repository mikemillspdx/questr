/** @format */

const { gql } = require('apollo-server-lambda');

module.exports = gql`
  extend type Query {
    meter_documents: [MeterDocument!]
    meter_document(id: ID!): MeterDocument!	
	meter_documents_by_location(location_id: Int!):  [MeterDocument!]
  }

  extend type Mutation {
    createNewMeterDocument(text: String!): MeterDocument!
    deleteMeterDocument(id: ID!): Boolean!
    updateMeterDocument(id: ID!, name: String!): MeterDocument!
  }

  type MeterDocument {
    id: ID!
	user_id: String
    name: String
    location_id: Int
    meter_name: String
	document_type: String
    filename: String
    last_edit: String
    deleted: Int
    validated: Int
  }
`;
