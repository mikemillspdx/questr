/** @format */

const { gql } = require('apollo-server-lambda');

module.exports = gql`
  extend type Query {
    meters(id: ID!): Meter!
    meter(id: ID!): Meter!
	meters_by_location(location_id: Int!):  [Meter!]
  }

  extend type Mutation {
    getMetersByLocation(location_id: Int!):  [Meter!]
    createNewMeter(text: String!): Meter!
    deleteMeter(id: ID!): Boolean!
    updateMeter(id: ID!, name: String!): Meter!
  }

  type Meter {
    id: ID!
	user_id: String
    name: String
    location_id: Int
    last_edit: String
    deleted: Int
    validated: Int
	meter_flow_type: String
	meter_measure_source_num: Int
	meter_distance_from_source: Boolean
	meter_type: String
	meter_brand: String
	meter_model_number: String
	meter_serial_number: String
	meter_measure: String
	meter_device_rollover: Int
	meter_fish_screen: Boolean
	meter_device_multiplier: Int
	meter_install_date: String
	meter_calibration_date: String
	meter_maintenance_date: String
  }
`;
