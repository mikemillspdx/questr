/** @format */

const { gql } = require('apollo-server-lambda');

module.exports = gql`
  extend type Query {
    pumps(id: ID!): Pump!
    pump(id: ID!): Pump!
	pumps_by_location(location_id: Int!):  [Pump!]
  }

  extend type Mutation {
    getPumpsByLocation(location_id: Int!):  [Pump!]
    createNewPump(text: String!): Pump!
    deletePump(id: ID!): Boolean!
    updatePump(id: ID!, name: String!): Pump!
  }

  type Pump {
    id: ID!
	user_id: String
    location_id: Int
    last_edit: String
    deleted: Int
    validated: Int
	pump_model: String 
	pump_sku: String
	serial_number: String
	pump_min_gpm: Int
	pump_max_gpm: Int
	pump_type: String
	pump_purchase_date: String
	pump_install_date: String
	pump_maintenance_date: String
	pump_curve_url: String
  }
`;
