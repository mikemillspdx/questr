/** @format */

const { gql } = require('apollo-server-lambda');

module.exports = gql`
  extend type Query {
    motors(id: ID!): Motor!
    motor(id: ID!): Motor!
	motors_by_location(location_id: Int!):  [Motor!]
  }

  extend type Mutation {
    getMotorsByLocation(location_id: Int!):  [Motor!]
    createNewMotor(text: String!): Motor!
    deleteMotor(id: ID!): Boolean!
    updateMotor(id: ID!, name: String!): Motor!
  }

  type Motor {
    id: ID!
	user_id: String
    location_id: Int
    last_edit: String
    deleted: Int
    validated: Int
	motor_model: String
    motor_sku: String
    serial_number: String
    motor_purchase_date: String
    motor_install_date: String
    motor_maintenance_date: String
    motor_pump_size: String
    motor_impeller_size: Int
    motor_type: String
  }
`;
