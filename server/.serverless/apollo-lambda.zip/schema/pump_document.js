/** @format */

const { gql } = require('apollo-server-lambda');

module.exports = gql`
  extend type Query {
    pump_documents: [PumpDocument!]
    pump_document(id: ID!): PumpDocument!	
	pump_documents_by_location(location_id: Int!):  [PumpDocument!]
  }

  extend type Mutation {
    createNewPumpDocument(text: String!): PumpDocument!
    deletePumpDocument(id: ID!): Boolean!
    updatePumpDocument(id: ID!, name: String!): PumpDocument!
  }

  type PumpDocument {
    id: ID!
	user_id: String
    name: String
    location_id: Int
    pump_name: String
	document_type: String
    filename: String
    last_edit: String
    deleted: Int
    validated: Int
  }
`;
