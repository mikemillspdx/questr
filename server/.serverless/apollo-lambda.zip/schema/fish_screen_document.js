/** @format */

const { gql } = require('apollo-server-lambda');

module.exports = gql`
  extend type Query {
    fish_screen_documents: [FishScreenDocument!]
    fish_screen_document(id: ID!): FishScreenDocument!	
	fish_screen_documents_by_location(location_id: Int!):  [FishScreenDocument!]
  }

  extend type Mutation {
    createNewFishScreenDocument(text: String!): FishScreenDocument!
    deleteFishScreenDocument(id: ID!): Boolean!
    updateFishScreenDocument(id: ID!, name: String!): FishScreenDocument!
  }

  type FishScreenDocument {
    id: ID!
	user_id: String
    name: String
    location_id: Int
    fish_screen_name: String
	document_type: String
    filename: String
    last_edit: String
    deleted: Int
    validated: Int
  }
`;
