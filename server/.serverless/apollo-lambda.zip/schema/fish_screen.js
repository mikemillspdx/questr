/** @format */

const { gql } = require('apollo-server-lambda');

module.exports = gql`
  extend type Query {
    fish_screens(id: ID!): FishScreen!
    fish_screen(id: ID!): FishScreen!
	fish_screens_by_location(location_id: Int!):  [FishScreen!]
  }

  extend type Mutation {
    getFishScreensByLocation(location_id: Int!):  [FishScreen!]
    createNewFishScreen(text: String!): FishScreen!
    deleteFishScreen(id: ID!): Boolean!
    updateFishScreen(id: ID!, name: String!): FishScreen!
  }

  type FishScreen {
    id: ID!
	user_id: String
    name: String
    mesh_size: String
    screen_type: String
    rotating_drum: String
    last_inspection: String
    screen_photo: String
    location_id: Int
    last_edit: String
    deleted: Int
    validated: Int
  }
`;
