/** @format */

const { gql } = require('apollo-server-lambda');

module.exports = gql`
  extend type Query {
    well_log_documents: [WellLogDocument!]
    well_log_document(id: ID!): WellLogDocument!	
	well_log_documents_by_location(location_id: Int!):  [WellLogDocument!]
  }

  extend type Mutation {
    createNewWellLogDocument(text: String!): WellLogDocument!
    deleteWellLogDocument(id: ID!): Boolean!
    updateWellLogDocument(id: ID!, name: String!): WellLogDocument!
  }

  type WellLogDocument {
    id: ID!
	user_id: String
    name: String
    location_id: Int
    well_log_name: String
	document_type: String
    filename: String
    last_edit: String
    deleted: Int
    validated: Int
  }
`;
