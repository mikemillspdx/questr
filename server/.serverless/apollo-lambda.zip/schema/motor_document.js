/** @format */

const { gql } = require('apollo-server-lambda');

module.exports = gql`
  extend type Query {
    motor_documents: [MotorDocument!]
    motor_document(id: ID!): MotorDocument!	
	motor_documents_by_location(location_id: Int!):  [MotorDocument!]
  }

  extend type Mutation {
    createNewMotorDocument(text: String!): MotorDocument!
    deleteMotorDocument(id: ID!): Boolean!
    updateMotorDocument(id: ID!, name: String!): MotorDocument!
  }

  type MotorDocument {
    id: ID!
	user_id: String
    name: String
    location_id: Int
    motor_name: String
	document_type: String
    filename: String
    last_edit: String
    deleted: Int
    validated: Int
  }
`;
