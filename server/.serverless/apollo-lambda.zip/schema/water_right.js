/** @format */

const { gql } = require('apollo-server-lambda');

module.exports = gql`
  extend type Query {
    water_rights(id: ID!): WaterRight!
    water_right(id: ID!): WaterRight!
	water_rights_by_location(location_id: Int!):  [WaterRight!]
  }

  extend type Mutation {
    getWaterRightByLocation(location_id: Int!):  [WaterRight!]
    createNewWaterRight(text: String!): WaterRight!
    deleteWaterRight(id: ID!): Boolean!
    updateWaterRight(id: ID!, name: String!): WaterRight!
  }

  type WaterRight {
    id: ID!
	user_id: String
    name: String
    location_id: Int
    water_source: String
    water_right_number: String
    rate: Float
	rate_unit: String
	volume: Float
	volume_unit: String
	acres: Float
	water_right_type: String
    notes: String
    last_edit: String
    deleted: Int
    validated: Int
  }
`;
