/** @format */

const { gql } = require('apollo-server-lambda');

module.exports = gql`
  extend type Query {
    well_logs(id: ID!): WellLog!
    well_log(id: ID!): WellLog!
	well_logs_by_location(location_id: Int!):  [WellLog!]
  }

  extend type Mutation {
    getWellLogsByLocation(location_id: Int!):  [WellLog!]
    createNewWellLog(text: String!): WellLog!
    deleteWellLog(id: ID!): Boolean!
    updateWellLog(id: ID!, name: String!): WellLog!
  }

  type WellLog {
    id: ID!
	user_id: String    
	location_id: Int
    name: String
	ecy_id: String 
	diameter: String 
	depth: String 
	aquifer: String 
	pump: String
	water_right: String
    last_edit: String
    deleted: Int
    validated: Int
  }
`;
