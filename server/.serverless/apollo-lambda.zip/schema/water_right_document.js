/** @format */

const { gql } = require('apollo-server-lambda');

module.exports = gql`
  extend type Query {
    water_right_documents: [WaterRightDocument!]
    water_right_document(id: ID!): WaterRightDocument!	
	water_right_documents_by_location(location_id: Int!):  [WaterRightDocument!]
  }

  extend type Mutation {
    createNewWaterRightDocument(text: String!): WaterRightDocument!
    deleteWaterRightDocument(id: ID!): Boolean!
    updateWaterRightDocument(id: ID!, name: String!): WaterRightDocument!
  }

  type WaterRightDocument {
    id: ID!
	user_id: String
    name: String
    location_id: Int
    water_right_number: String
	document_type: String
    filename: String
    last_edit: String
    deleted: Int
    validated: Int
  }
`;
